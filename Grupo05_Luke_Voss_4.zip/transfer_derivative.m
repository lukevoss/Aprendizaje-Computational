function output = transfer_derivative(output)
output = output * (1.0-output);
end